/**
 * NingZeLogs JavaScript SDK
 * Simple wrapper for the mclogs API
 */
class Mclogs {
    constructor(baseUrl = 'https://api.mclogs.lemwood.icu') {
        this.baseUrl = baseUrl;
    }

    /**
     * Paste log content
     * @param {string} content 
     * @returns {Promise<object>}
     */
    async paste(content) {
        const response = await fetch(`${this.baseUrl}/1/log`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({ content })
        });
        return await response.json();
    }

    /**
     * Get raw log content
     * @param {string} id 
     * @returns {Promise<string>}
     */
    async getRaw(id) {
        const response = await fetch(`${this.baseUrl}/1/raw/${id}`);
        return await response.text();
    }

    /**
     * Get log insights
     * @param {string} id 
     * @returns {Promise<object>}
     */
    async getInsights(id) {
        const response = await fetch(`${this.baseUrl}/1/insights/${id}`);
        return await response.json();
    }

    /**
     * Analyse log without saving
     * @param {string} content 
     * @returns {Promise<object>}
     */
    async analyse(content) {
        const response = await fetch(`${this.baseUrl}/1/analyse`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({ content })
        });
        return await response.json();
    }
}

// Export for different environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Mclogs;
} else {
    window.Mclogs = Mclogs;
}
