<?php

/**
 * NingZeLogs PHP SDK
 * Simple wrapper for the mclogs API using cURL
 */
class Mclogs
{
    private string $baseUrl;

    public function __construct(string $baseUrl = 'https://api.mclogs.lemwood.icu')
    {
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    /**
     * Paste log content
     * 
     * @param string $content
     * @return array
     */
    public function paste(string $content): array
    {
        return $this->request('/1/log', 'POST', ['content' => $content]);
    }

    /**
     * Get raw log content
     * 
     * @param string $id
     * @return string
     */
    public function getRaw(string $id): string
    {
        return $this->requestRaw('/1/raw/' . $id);
    }

    /**
     * Get log insights
     * 
     * @param string $id
     * @return array
     */
    public function getInsights(string $id): array
    {
        return $this->request('/1/insights/' . $id);
    }

    /**
     * Analyse log without saving
     * 
     * @param string $content
     * @return array
     */
    public function analyse(string $content): array
    {
        return $this->request('/1/analyse', 'POST', ['content' => $content]);
    }

    /**
     * Perform JSON request
     */
    private function request(string $endpoint, string $method = 'GET', array $data = []): array
    {
        $response = $this->requestRaw($endpoint, $method, $data);
        return json_decode($response, true) ?? ['success' => false, 'error' => 'Invalid JSON response'];
    }

    /**
     * Perform raw request
     */
    private function requestRaw(string $endpoint, string $method = 'GET', array $data = []): string
    {
        $ch = curl_init($this->baseUrl . $endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }

        $result = curl_exec($ch);
        curl_close($ch);

        return $result ?: '';
    }
}
